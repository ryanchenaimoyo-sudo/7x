// App.js
// Single-file Snack-ready app with optional Firebase wiring.
// Dependencies required in Snack:
//   firebase
//   expo-auth-session
//   expo-image-picker
//   @react-native-async-storage/async-storage
//
// Instructions:
// 1) Add the Snack dependencies listed above.
// 2) Replace the firebaseConfig placeholders below with your Firebase Web app config (from Firebase Console).
// 3) If you want Google sign-in, create a Google OAuth Web client ID and paste into GOOGLE_WEB_CLIENT_ID.
// 4) Run in Expo Go: when firebaseConfig.apiKey is set the app uses Firebase (cloud); otherwise it runs local AsyncStorage mode.

import React, { useEffect, useState, useRef } from "react";
import {
  SafeAreaView,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  Modal,
  StyleSheet,
  Image,
  Alert,
  Platform,
  KeyboardAvoidingView,
  ActivityIndicator,
} from "react-native";
import * as ImagePicker from "expo-image-picker";
import AsyncStorage from "@react-native-async-storage/async-storage";

/* ---------------------------
   CONFIG - Paste your Firebase config here to enable cloud mode
   --------------------------- */
// If you leave apiKey as "YOUR_API_KEY" the app will run in local mode.
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "SENDER_ID",
  appId: "APP_ID",
};

// Google OAuth (optional, used by expo-auth-session client flow)
// Create a "Web application" OAuth Client ID in Google Cloud Console and paste it here.
const GOOGLE_WEB_CLIENT_ID = ""; // e.g. "12345-abc.apps.googleusercontent.com"

/* ---------------------------
   Conditional Firebase init (modular v9)
   The code loads firebase only if user pasted config (avoid poluting local-only runs)
   --------------------------- */
let firebase = null;
let auth = null;
let db = null;
let storage = null;
let firebaseImports = null;
let isCloud = Boolean(firebaseConfig && firebaseConfig.apiKey && firebaseConfig.apiKey !== "YOUR_API_KEY");

if (isCloud) {
  try {
    // import firebase modular SDK
    // eslint-disable-next-line no-unused-vars
    import("firebase/app").then(({ initializeApp }) => {
      // dynamic imports for other modules
      Promise.all([
        import("firebase/auth"),
        import("firebase/firestore"),
        import("firebase/storage"),
      ])
        .then(([authMod, firestoreMod, storageMod]) => {
          const app = initializeApp(firebaseConfig);
          // auth
          const { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut, onAuthStateChanged, GoogleAuthProvider, signInWithCredential } = authMod;
          auth = getAuth(app);
          // firestore
          const { getFirestore, collection, addDoc, doc, setDoc, getDoc, onSnapshot, query, orderBy, serverTimestamp, updateDoc, getDocs, where } = firestoreMod;
          db = getFirestore(app);
          // storage
          const { getStorage, ref: storageRef, uploadBytesResumable, getDownloadURL } = storageMod;
          storage = getStorage(app);

          firebaseImports = {
            authMod,
            firestoreMod,
            storageMod,
            getAuth,
            signInWithEmailAndPassword,
            createUserWithEmailAndPassword,
            signOut,
            onAuthStateChanged,
            GoogleAuthProvider,
            signInWithCredential,
            getFirestore,
            collection,
            addDoc,
            doc,
            setDoc,
            getDoc,
            onSnapshot,
            query,
            orderBy,
            serverTimestamp,
            updateDoc,
            getDocs,
            where,
            getStorage,
            storageRef,
            uploadBytesResumable,
            getDownloadURL,
          };
        })
        .catch((e) => {
          console.warn("Firebase module import failed:", e);
          // fallback to local mode if imports fail
          firebaseImports = null;
          auth = null;
          db = null;
          storage = null;
        });
    });
  } catch (e) {
    console.warn("Firebase init error", e);
    isCloud = false;
  }
}

/* ---------------------------
   Storage keys & Local Controller (fallback)
   --------------------------- */
const StorageKeys = {
  POSTS: "@tstar_posts_v1",
  SESSION: "@tstar_session_v1",
  BLOCKS: "@tstar_blocks_v1",
  REPORTS: "@tstar_reports_v1",
};

const LocalController = {
  save: async (key, value) => {
    try {
      await AsyncStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
      console.warn("Local save failed", e);
    }
  },
  load: async (key, fallback = null) => {
    try {
      const raw = await AsyncStorage.getItem(key);
      if (!raw) return fallback;
      return JSON.parse(raw);
    } catch (e) {
      console.warn("Local load failed", e);
      return fallback;
    }
  },
  seedIfNeeded: async () => {
    const posts = await LocalController.load(StorageKeys.POSTS, null);
    if (!posts) {
      const starter = [
        {
          id: "p" + Date.now(),
          author: "System",
          text: "Welcome to T-Star Traders (local demo). Paste Firebase config to enable cloud mode.",
          imageUri: null,
          likes: 0,
          comments: [],
          createdAt: Date.now(),
        },
      ];
      await LocalController.save(StorageKeys.POSTS, starter);
    }
  },
};

/* ---------------------------
   Utility: small helper to compress/reduce image size before upload
   Note: expo-image-picker quality param helps; further compression may need libraries.
   --------------------------- */
async function uriToBlob(uri) {
  // fetch and convert to blob
  const response = await fetch(uri);
  const blob = await response.blob();
  return blob;
}

/* ---------------------------
   Main App
   --------------------------- */
export default function App() {
  const [mode, setMode] = useState(isCloud ? "cloud-init" : "local"); // states: cloud-init, local, cloud-ready
  const [loading, setLoading] = useState(true);

  // common UI state
  const [posts, setPosts] = useState([]);
  const [session, setSession] = useState(null); // { uid, displayName, email }
  const [blocks, setBlocks] = useState({});
  const [reports, setReports] = useState([]);
  const [commentsOpen, setCommentsOpen] = useState(false);
  const [activePost, setActivePost] = useState(null);
  const cloudUnsubRef = useRef(null);

  // initialize
  useEffect(() => {
    (async () => {
      if (isCloud && firebaseImports && auth && db) {
        // cloud mode ready
        setMode("cloud-ready");
        // attach auth listener
        try {
          const { onAuthStateChanged } = firebaseImports;
          onAuthStateChanged(auth, (user) => {
            if (user) {
              setSession({ uid: user.uid, displayName: user.displayName || user.email || "Trader", email: user.email || null });
            } else {
              setSession(null);
            }
          });
        } catch (e) {
          console.warn("auth listener failed", e);
        }

        // subscribe to posts collection
        try {
          const { collection, query, orderBy, onSnapshot } = firebaseImports;
          const postsCol = collection(db, "posts");
          const q = query(postsCol, orderBy("createdAt", "desc"));
          cloudUnsubRef.current = onSnapshot(q, (snap) => {
            const docs = snap.docs.map((d) => {
              const data = d.data();
              return {
                id: d.id,
                text: data.text,
                author: data.authorName || data.author || "Unknown",
                imageUri: data.imageUrl || null,
                likes: data.likes || 0,
                comments: data.commentsCount || 0,
                createdAt: data.createdAt ? data.createdAt.toMillis ? data.createdAt.toMillis() : data.createdAt : Date.now(),
              };
            });
            setPosts(docs);
          });
        } catch (e) {
          console.warn("subscribe posts failed", e);
        }

        // load blocks/reports locally (we store these locally to avoid exposing moderator tools)
        const b = (await LocalController.load(StorageKeys.BLOCKS, {})) || {};
        const r = (await LocalController.load(StorageKeys.REPORTS, [])) || [];
        setBlocks(b);
        setReports(r);

        setLoading(false);
        return;
      }

      // local mode initial load
      try {
        await LocalController.seedIfNeeded();
        const localPosts = (await LocalController.load(StorageKeys.POSTS, [])) || [];
        const localSession = (await LocalController.load(StorageKeys.SESSION, null)) || null;
        const localBlocks = (await LocalController.load(StorageKeys.BLOCKS, {})) || {};
        const localReports = (await LocalController.load(StorageKeys.REPORTS, [])) || [];
        setPosts(localPosts);
        setSession(localSession);
        setBlocks(localBlocks);
        setReports(localReports);
        setMode("local");
      } catch (e) {
        console.warn("local init failed", e);
      } finally {
        setLoading(false);
      }
    })();

    return () => {
      if (cloudUnsubRef.current) {
        cloudUnsubRef.current();
        cloudUnsubRef.current = null;
      }
    };
  }, []);

  /* ---------------------------
     Cloud: Auth helpers (email + google)
     --------------------------- */
  const cloudSignUpEmail = async (email, password, displayName) => {
    try {
      const { createUserWithEmailAndPassword, setDoc, doc, collection } = firebaseImports;
      const cred = await createUserWithEmailAndPassword(auth, email, password);
      // save profile in users collection
      const usersColRef = doc(db, "users", cred.user.uid);
      await setDoc(usersColRef, { uid: cred.user.uid, email: email, displayName: displayName || email, createdAt: firebaseImports.serverTimestamp() });
      return { uid: cred.user.uid, displayName: displayName || email, email };
    } catch (e) {
      throw e;
    }
  };

  const cloudSignInEmail = async (email, password) => {
    try {
      const { signInWithEmailAndPassword } = firebaseImports;
      const cred = await signInWithEmailAndPassword(auth, email, password);
      return { uid: cred.user.uid, displayName: cred.user.displayName || cred.user.email };
    } catch (e) {
      throw e;
    }
  };

  // Google sign-in using expo-auth-session
  const cloudSignInGoogle = async (requestPromptAsync) => {
    if (!GOOGLE_WEB_CLIENT_ID) {
      Alert.alert("Google Sign-in", "No GOOGLE_WEB_CLIENT_ID configured. You can sign in with email/password instead.");
      return null;
    }
    try {
      // use expo-auth-session provider flow
      const { startAsync } = await import("expo-auth-session");
      // Use the recommended provider helper: expo-auth-session/providers/google
      const google = await import("expo-auth-session/providers/google");
      const [request, response, promptAsync] = google.useAuthRequest({
        expoClientId: GOOGLE_WEB_CLIENT_ID,
        webClientId: GOOGLE_WEB_CLIENT_ID,
      });
      // We need to call promptAsync() from UI; for simplicity we'll pop a note to user to use email when in Snack.
      Alert.alert("Google sign-in", "Google sign-in is available in standalone apps. In Snack it may be limited. Use email sign-in for now.");
      return null;
    } catch (e) {
      console.warn("Google sign-in failed", e);
      return null;
    }
  };

  /* ---------------------------
     Cloud: Firestore actions
     --------------------------- */
  const cloudCreatePost = async (text, imageUri) => {
    try {
      const { collection, addDoc, serverTimestamp } = firebaseImports;
      const postsCol = collection(db, "posts");
      const payload = {
        text,
        authorUid: session?.uid || "anon",
        authorName: session?.displayName || "Guest",
        createdAt: serverTimestamp(),
        likes: 0,
        commentsCount: 0,
        imageUrl: null,
      };
      // if image provided upload and set imageUrl
      if (imageUri && storage && firebaseImports) {
        const url = await uploadImageToStorage(imageUri);
        payload.imageUrl = url;
      }
      const docRef = await addDoc(postsCol, payload);
      return docRef.id;
    } catch (e) {
      console.warn("cloudCreatePost failed", e);
      throw e;
    }
  };

  const cloudAddComment = async (postId, text) => {
    try {
      const { collection, addDoc, doc, updateDoc, getDoc, serverTimestamp } = firebaseImports;
      const commentsRef = collection(db, "posts", postId, "comments");
      await addDoc(commentsRef, { text, authorUid: session?.uid || "anon", authorName: session?.displayName || "Guest", createdAt: serverTimestamp() });
      // increment commentsCount (simple update; use transaction in prod)
      const pRef = doc(db, "posts", postId);
      const snap = await getDoc(pRef);
      const current = (snap.data()?.commentsCount) || 0;
      await updateDoc(pRef, { commentsCount: current + 1 });
    } catch (e) {
      console.warn("cloudAddComment failed", e);
      throw e;
    }
  };

  const cloudLikePost = async (postId) => {
    try {
      const { doc, getDoc, updateDoc } = firebaseImports;
      const pRef = doc(db, "posts", postId);
      const snap = await getDoc(pRef);
      const current = (snap.data()?.likes) || 0;
      await updateDoc(pRef, { likes: current + 1 });
    } catch (e) {
      console.warn("cloudLikePost failed", e);
      throw e;
    }
  };

  const uploadImageToStorage = async (uri) => {
    try {
      const { storageRef, uploadBytesResumable, getDownloadURL } = firebaseImports;
      const blob = await uriToBlob(uri);
      const filename = `images/${Date.now()}_${Math.random().toString(36).substring(2, 8)}.jpg`;
      const ref = storageRef(storage, filename);
      const snap = await uploadBytesResumable(ref, blob);
      const url = await getDownloadURL(snap.ref);
      return url;
    } catch (e) {
      console.warn("uploadImageToStorage failed", e);
      throw e;
    }
  };

  /* ---------------------------
     Local mode actions (fallback)
     --------------------------- */
  const localCreatePost = async (text, imageUri) => {
    try {
      const postsLocal = (await LocalController.load(StorageKeys.POSTS, [])) || [];
      const newp = { id: "p" + Date.now(), author: session?.displayName || "Guest", text, imageUri: imageUri || null, likes: 0, comments: [], createdAt: Date.now() };
      const next = [newp, ...postsLocal].slice(0, 500);
      await LocalController.save(StorageKeys.POSTS, next);
      setPosts(next);
    } catch (e) {
      console.warn("localCreatePost failed", e);
    }
  };

  const localAddComment = async (postId, text) => {
    try {
      const postsLocal = (await LocalController.load(StorageKeys.POSTS, [])) || [];
      const next = postsLocal.map((p) => (p.id === postId ? { ...p, comments: [...p.comments, { id: "c" + Date.now(), author: session?.displayName || "Guest", text, createdAt: Date.now() }] } : p));
      await LocalController.save(StorageKeys.POSTS, next);
      setPosts(next);
    } catch (e) {
      console.warn("localAddComment failed", e);
    }
  };

  const localLikePost = async (postId) => {
    try {
      const postsLocal = (await LocalController.load(StorageKeys.POSTS, [])) || [];
      const next = postsLocal.map((p) => (p.id === postId ? { ...p, likes: (p.likes || 0) + 1 } : p));
      await LocalController.save(StorageKeys.POSTS, next);
      setPosts(next);
    } catch (e) {
      console.warn("localLikePost failed", e);
    }
  };

  /* ---------------------------
     Shared UI actions that pick appropriate mode
     --------------------------- */
  const createPost = async (text, imageUri) => {
    if (mode === "cloud-ready") {
      try {
        await cloudCreatePost(text, imageUri);
        // posts will update via onSnapshot
      } catch (e) {
        Alert.alert("Error", "Could not create post in cloud. Falling back to local save.");
        await localCreatePost(text, imageUri);
      }
    } else {
      await localCreatePost(text, imageUri);
    }
  };

  const addComment = async (postId, text) => {
    if (mode === "cloud-ready") {
      try {
        await cloudAddComment(postId, text);
      } catch (e) {
        Alert.alert("Error", "Could not add comment to cloud. Saving locally.");
        await localAddComment(postId, text);
      }
    } else {
      await localAddComment(postId, text);
    }
  };

  const likePost = async (postId) => {
    if (mode === "cloud-ready") {
      try {
        await cloudLikePost(postId);
      } catch (e) {
        await localLikePost(postId);
      }
    } else {
      await localLikePost(postId);
    }
  };

  /* ---------------------------
     Auth UI: local sign-in and cloud sign-in UI
     --------------------------- */
  const localSignIn = async (displayName) => {
    const u = { uid: "u" + Date.now(), displayName: displayName || "Trader", email: null };
    await LocalController.save(StorageKeys.SESSION, u);
    setSession(u);
  };

  const localSignOut = async () => {
    await LocalController.save(StorageKeys.SESSION, null);
    setSession(null);
  };

  const cloudSignOut = async () => {
    try {
      const { signOut } = firebaseImports;
      await signOut(auth);
    } catch (e) {
      console.warn("cloud sign out failed", e);
    }
  };

  /* ---------------------------
     UI components (kept small to focus on wiring)
     --------------------------- */
  const [composerText, setComposerText] = useState("");
  const [composerImage, setComposerImage] = useState(null);
  const [signModalVisible, setSignModalVisible] = useState(false);
  const [emailModalVisible, setEmailModalVisible] = useState(false);
  const [emailForm, setEmailForm] = useState({ email: "", password: "", displayName: "" });

  // pick image (works in cloud mode and local mode)
  const pickImageLocal = async () => {
    try {
      const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (perm.status !== "granted") {
        Alert.alert("Permission needed", "Allow access to photos to attach images.");
        return;
      }
      const res = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 0.6, allowsEditing: true });
      const uri = res?.assets?.[0]?.uri ?? res?.uri ?? null;
      if (res.cancelled || !uri) return;
      setComposerImage(uri);
    } catch (e) {
      console.warn("pickImage failed", e);
      Alert.alert("Error", "Could not pick image.");
    }
  };

  // post button pressed
  const onPressPost = async () => {
    if (!composerText || composerText.trim() === "") {
      Alert.alert("Empty", "Write something before posting.");
      return;
    }
    if (composerText.length > 2000) {
      Alert.alert("Too long", "Please keep posts under 2000 characters.");
      return;
    }
    // basic profanity filter
    if ((composerText || "").toLowerCase().includes("badword")) {
      Alert.alert("Blocked", "Your post contains disallowed text.");
      return;
    }

    // create
    await createPost(composerText.trim(), composerImage);
    setComposerText("");
    setComposerImage(null);
  };

  // create email account (cloud)
  const handleCloudEmailSignup = async () => {
    const { email, password, displayName } = emailForm;
    if (!email || !password) {
      Alert.alert("Missing", "Email and password required.");
      return;
    }
    try {
      if (!firebaseImports) throw new Error("Firebase not initialized");
      await cloudSignUpEmail(email, password, displayName);
      Alert.alert("Account created", "You can now sign in with email.");
      setEmailModalVisible(false);
    } catch (e) {
      console.warn("signup error", e);
      Alert.alert("Signup failed", e.message || "Error");
    }
  };

  const handleCloudEmailSignin = async () => {
    const { email, password } = emailForm;
    if (!email || !password) {
      Alert.alert("Missing", "Email and password required.");
      return;
    }
    try {
      if (!firebaseImports) throw new Error("Firebase not initialized");
      await cloudSignInEmail(email, password);
      setEmailModalVisible(false);
    } catch (e) {
      console.warn("signin error", e);
      Alert.alert("Sign in failed", e.message || "Error");
    }
  };

  // report and block functions (store locally to avoid cloud moderation complexity)
  const reportPost = async (postId) => {
    const r = (await LocalController.load(StorageKeys.REPORTS, [])) || [];
    const newr = { id: "r" + Date.now(), postId, reporter: session?.displayName || "Guest", createdAt: Date.now() };
    const next = [newr, ...r].slice(0, 1000);
    await LocalController.save(StorageKeys.REPORTS, next);
    setReports(next);
    Alert.alert("Reported", "Post reported (locally).");
  };

  const blockAuthor = async (author) => {
    const blocksLocal = (await LocalController.load(StorageKeys.BLOCKS, {})) || {};
    const me = session?.uid || "guest";
    const userBlocks = blocksLocal[me] || [];
    const next = { ...blocksLocal, [me]: Array.from(new Set([...userBlocks, author])) };
    await LocalController.save(StorageKeys.BLOCKS, next);
    setBlocks(next);
    Alert.alert("Blocked", `${author} is blocked locally.`);
  };

  /* ---------------------------
     UI rendering
     --------------------------- */
  if (loading) return <SafeAreaView style={[styles.container, { justifyContent: "center", alignItems: "center" }]}><ActivityIndicator size="large" /></SafeAreaView>;

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerStar}>⭐</Text>
        <Text style={styles.headerTitle}>T-Star Traders {mode === "cloud-ready" ? "(Cloud)" : "(Local)"}</Text>
        <View style={{ flexDirection: "row", alignItems: "center" }}>
          {session ? (
            <>
              <Text style={styles.headerUser}>@{session.displayName}</Text>
              <TouchableOpacity onPress={async () => { if (mode === "cloud-ready") await cloudSignOut(); else await localSignOut(); }} style={{ marginLeft: 8 }}>
                <Text style={styles.signOut}>Sign out</Text>
              </TouchableOpacity>
            </>
          ) : (
            <TouchableOpacity onPress={() => setSignModalVisible(true)}>
              <Text style={styles.headerUser}>Sign in</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>

      {/* Composer */}
      <View style={styles.composer}>
        <TextInput style={[styles.input, { minHeight: 48 }]} placeholder="Share an idea..." value={composerText} onChangeText={setComposerText} multiline />
        {composerImage ? <Image source={{ uri: composerImage }} style={styles.previewImage} /> : null}
        <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
          <View style={{ flexDirection: "row", alignItems: "center" }}>
            <TouchableOpacity style={styles.iconButton} onPress={pickImageLocal}><Text>📷</Text></TouchableOpacity>
          </View>
          <TouchableOpacity style={[styles.button, { paddingHorizontal: 16 }]} onPress={onPressPost}><Text style={styles.buttonText}>Post</Text></TouchableOpacity>
        </View>
      </View>

      {/* Posts list */}
      <FlatList
        data={posts}
        keyExtractor={(i) => i.id}
        renderItem={({ item }) => (
          <View style={styles.post}>
            <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
              <Text style={styles.postAuthor}>{item.author}</Text>
              <Text style={styles.postTime}>{new Date(item.createdAt).toLocaleString()}</Text>
            </View>
            <Text style={styles.postText}>{item.text}</Text>
            {item.imageUri ? <Image source={{ uri: item.imageUri }} style={styles.postImage} /> : null}
            <View style={styles.postActions}>
              <TouchableOpacity onPress={() => likePost(item.id)} style={styles.actionButton}><Text>👍 {item.likes}</Text></TouchableOpacity>
              <TouchableOpacity onPress={() => { setActivePost(item); setCommentsOpen(true); }} style={styles.actionButton}><Text>💬 {item.comments ?? 0}</Text></TouchableOpacity>
              <TouchableOpacity onPress={() => reportPost(item.id)} style={styles.actionButton}><Text>🚩</Text></TouchableOpacity>
              <TouchableOpacity onPress={() => blockAuthor(item.author)} style={styles.actionButton}><Text>🔒 Block</Text></TouchableOpacity>
            </View>
          </View>
        )}
        contentContainerStyle={{ paddingBottom: 120 }}
        ListEmptyComponent={<Text style={{ padding: 12, color: "#666" }}>No posts yet — be first!</Text>}
      />

      {/* Comments modal */}
      <CommentsModal
        visible={commentsOpen}
        post={activePost}
        onClose={() => { setCommentsOpen(false); setActivePost(null); }}
        onAddComment={async (postId, text) => {
          await addComment(postId, text);
        }}
      />

      {/* Sign modal */}
      <Modal visible={signModalVisible} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <Text style={{ fontSize: 18, fontWeight: "700" }}>Sign in / Create account</Text>
            <Text style={{ marginTop: 8, color: "#333" }}>Pick an option:</Text>

            <TouchableOpacity style={[styles.button, { marginTop: 12 }]} onPress={() => { setEmailModalVisible(true); }}>
              <Text style={styles.buttonText}>Email / Password</Text>
            </TouchableOpacity>

            <TouchableOpacity style={[styles.button, { marginTop: 12 }]} onPress={async () => {
              if (mode === "cloud-ready") {
                Alert.alert("Google Sign-in", "Google flow is limited in Snack — use email for testing or build a standalone app and configure OAuth client correctly.");
              } else {
                Alert.alert("Local Sign-in", "Creating a local account for demo.");
                const name = `Trader${Math.floor(Math.random() * 1000)}`;
                await localSignIn(name);
                setSignModalVisible(false);
              }
            }}>
              <Text style={styles.buttonText}>{mode === "cloud-ready" ? "Sign in with Google (standalone only)" : "Local quick sign-in"}</Text>
            </TouchableOpacity>

            <TouchableOpacity onPress={() => setSignModalVisible(false)} style={[styles.button, { marginTop: 12, backgroundColor: "#ddd" }]}>
              <Text style={{ color: "#333", fontWeight: "700" }}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Email modal (cloud sign up / sign in) */}
      <Modal visible={emailModalVisible} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <Text style={{ fontSize: 16, fontWeight: "700" }}>Email Sign-in / Sign-up</Text>
            <TextInput placeholder="Email" style={[styles.input, { marginTop: 8 }]} value={emailForm.email} onChangeText={(t) => setEmailForm((s) => ({ ...s, email: t }))} keyboardType="email-address" autoCapitalize="none" />
            <TextInput placeholder="Password" style={[styles.input, { marginTop: 8 }]} value={emailForm.password} onChangeText={(t) => setEmailForm((s) => ({ ...s, password: t }))} secureTextEntry />
            <TextInput placeholder="Display name (optional)" style={[styles.input, { marginTop: 8 }]} value={emailForm.displayName} onChangeText={(t) => setEmailForm((s) => ({ ...s, displayName: t }))} />

            <View style={{ flexDirection: "row", justifyContent: "space-between", marginTop: 12 }}>
              <TouchableOpacity onPress={async () => { await handleCloudEmailSignup(); }} style={[styles.button, { flex: 1, marginRight: 6 }]}>
                <Text style={styles.buttonText}>Create account</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={async () => { await handleCloudEmailSignin(); }} style={[styles.button, { flex: 1, marginLeft: 6 }]}>
                <Text style={styles.buttonText}>Sign in</Text>
              </TouchableOpacity>
            </View>

            <TouchableOpacity onPress={() => setEmailModalVisible(false)} style={[styles.button, { marginTop: 12, backgroundColor: "#ddd" }]}>
              <Text style={{ color: "#333", fontWeight: "700" }}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

    </SafeAreaView>
  );
}

/* CommentsModal component used above */
const CommentsModal = ({ visible, post, onClose, onAddComment }) => {
  const [text, setText] = useState("");
  useEffect(() => setText(""), [visible, post]);
  if (!post) return null;
  return (
    <Modal visible={visible} animationType="slide">
      <SafeAreaView style={{ flex: 1 }}>
        <View style={styles.modalHeader}>
          <Text style={styles.modalTitle}>Comments</Text>
          <TouchableOpacity onPress={onClose}><Text style={{ color: "#007aff" }}>Close</Text></TouchableOpacity>
        </View>
        <FlatList data={post.comments || []} keyExtractor={(c) => c.id} renderItem={({ item }) => (
          <View style={styles.commentRow}>
            <Text style={styles.commentAuthor}>{item.author}</Text>
            <Text style={styles.commentText}>{item.text}</Text>
          </View>
        )} ListEmptyComponent={<Text style={{ padding: 16 }}>No comments yet</Text>} />
        <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"}>
          <View style={styles.commentComposer}>
            <TextInput style={[styles.input, { flex: 1 }]} placeholder="Write a comment..." value={text} onChangeText={setText} />
            <TouchableOpacity style={styles.button} onPress={async () => { if (!text || text.trim() === "") return; await onAddComment(post.id, text.trim()); setText(""); }}>
              <Text style={styles.buttonText}>Send</Text>
            </TouchableOpacity>
          </View>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </Modal>
  );
};

/* ---------------------------
   Basic styles (same theme)
   --------------------------- */
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#f4f7fb" },
  header: {
    height: 64,
    backgroundColor: "#081029",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 12,
  },
  headerStar: { fontSize: 28, color: "#ffd54a" },
  headerTitle: { color: "#fff", fontSize: 16, fontWeight: "700" },
  headerUser: { color: "#ddd", marginLeft: 8 },
  signOut: { color: "#ff6b6b" },

  composer: { backgroundColor: "#fff", padding: 10, margin: 8, borderRadius: 10 },
  input: { backgroundColor: "#f7f9fc", padding: 10, borderRadius: 8, marginBottom: 8 },
  previewImage: { width: 120, height: 80, borderRadius: 8, marginBottom: 8 },

  button: {
    backgroundColor: "#007aff",
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 8,
  },
  buttonText: { color: "#fff", fontWeight: "700" },

  iconButton: { backgroundColor: "#eef6ff", padding: 8, borderRadius: 8, marginRight: 8 },

  post: { backgroundColor: "#fff", margin: 10, padding: 12, borderRadius: 10 },
  postAuthor: { fontWeight: "700" },
  postTime: { color: "#666", fontSize: 12 },
  postText: { marginTop: 8, fontSize: 15 },
  postImage: { width: "100%", height: 180, borderRadius: 8, marginTop: 8 },
  postActions: { flexDirection: "row", marginTop: 12, alignItems: "center" },
  actionButton: { marginRight: 12 },

  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    padding: 12,
    borderBottomWidth: 1,
    borderColor: "#eee",
  },
  modalTitle: { fontSize: 18, fontWeight: "700" },
  commentRow: { padding: 12, borderBottomWidth: 1, borderColor: "#f0f0f0" },
  commentAuthor: { fontWeight: "700" },
  commentText: { marginTop: 4 },
  commentComposer: { flexDirection: "row", padding: 12, alignItems: "center" },

  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.4)", justifyContent: "center", padding: 20 },
  modalCard: { backgroundColor: "#fff", padding: 16, borderRadius: 12 },
});